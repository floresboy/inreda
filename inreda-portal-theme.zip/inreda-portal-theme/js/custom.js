/* ---------------------------------------------
* Filename:     custom.js
* Version:      1.0.0 (2016-03-05)
* Website:      -
* Description:  Global Script
* Author:       -
-----------------------------------------------*/

jQuery(document).ready(function ($)
{
  // Check notify user during role creation
  if(jQuery('#edit-notify').length)
  {
    jQuery('#edit-notify').prop("checked", true);
  }

  // Diable role selecting during user creation
  // if(jQuery('#edit-roles').length)
  // {
  //   jQuery("#edit-roles").children().eq(1).remove(); //Remove administrator
  //
  //   do {
  //     jQuery("#edit-roles").children().eq(3).remove();
  //
  //   } while(3 != jQuery("#edit-roles").children().length);
  // }

  if(jQuery('#edit-pass').length)
  {
    jQuery("#edit-account").find("#edit-pass").remove();
  }

});